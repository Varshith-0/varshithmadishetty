from setuptools import setup, find_packages

setup(
    name="varshithmadishetty",  # pip install varshithmadishetty
    version="0.1",
    packages=find_packages(),
    description="A library that takes anything and says 'Fuck you'",
    author="Varshith Madishetty",
    python_requires=">=3.6",
)
